function rol_user(password) {
    if(password != 'admin') {
      return = true
    } else {
       return = rol_admin() 
    }
}
function rol_admin(email) {
   if(email === 'admin') {
     return = true  
   } else {
       return = rol_user()
       alert('Redireccionando...');
   }
}
if(confirmar = true) {
 let confirmar = confirm("¿Borrar usuario?")
 alert('Usuario borrado')
}

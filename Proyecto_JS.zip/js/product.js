if(confirmar = true) {   
let confirmar = confirm("¿Borrar producto?");
 alert('Producto borrado')
 }

alert('Nuevo producto añadido')
